package com.nadikarim.submision1.data.model.login

data class LoginRequest(
    val email: String,
    val password: String
)
