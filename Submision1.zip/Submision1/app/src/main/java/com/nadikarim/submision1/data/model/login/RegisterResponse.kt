package com.nadikarim.submision1.data.model.login

data class RegisterResponse(
    val error: Boolean,
    val message: String
)