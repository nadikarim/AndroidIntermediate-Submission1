package com.nadikarim.submision1.data.model.login

data class LoginResult(
    var name: String,
    var token: String,
    var userId: String
)