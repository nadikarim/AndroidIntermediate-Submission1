package com.nadikarim.submision1.data.model.stories

data class AddResponse(
    val error: Boolean,
    val message: String
)