package com.nadikarim.submision1.data.model.login

data class RegisterRequest(
    val name: String,
    val email: String,
    val password: String
)
